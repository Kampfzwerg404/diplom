﻿namespace ASP_Eight.Data.Models
{
    public class CartItem
    {
        public CartItem() { }

        public CartItem(Car? car, int quantity, int userId)
        {
            Car = car;
            Quantity = quantity;
            UserId = userId;
        }

        public CartItem(int id, Car? car, int quantity, int userId)
        {
            Id = id;
            Car = car;
            Quantity = quantity;
            UserId = userId;
        }

        public int Id { get; set; }
        public Car? Car { get; set; }
        public int Quantity { get; set; }
        public int UserId { get; set; }
    }
}
