﻿namespace ASP_Eight.Data.Models
{
    public class Category
    {
        public Category() { }

        public Category(int id, string name, string description)
        {
            Id = id;
            Name = name;
            Description = description;
        }

        public Category(string name, string description)
        {
            Name = name;
            Description = description;
        }

        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public ICollection<Car>? Cars { get; set; }
    }
}
