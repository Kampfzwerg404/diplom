﻿namespace ASP_Eight.Data.Models
{
    public class Car
    {
        public Car() { }

        public Car(string name, string shortDesc, string fullDesc, string img, int price, bool isFavourite, bool available, int categoryId, int userId)
        {
            Name = name;
            ShortDesc = shortDesc;
            FullDesc = fullDesc;
            Img = img;
            Price = price;
            IsFavourite = isFavourite;
            Available = available;
            CategoryId = categoryId;
            UserId = userId;
        }

        public Car(int id, string name, string shortDesc, string fullDesc, string img, int price, bool isFavourite, bool available, int categoryId, int userId)
        {
            Id = id;
            Name = name;
            ShortDesc = shortDesc;
            FullDesc = fullDesc;
            Img = img;
            Price = price;
            IsFavourite = isFavourite;
            Available = available;
            CategoryId = categoryId;
            UserId = userId;
        }

        public int Id { get; set; }
        public string? Name { get; set; }
        public string? ShortDesc { get; set; }
        public string? FullDesc { get; set; }
        public string? Img { get; set; }
        public int Price { get; set; }
        public bool IsFavourite { get; set; }
        public bool Available { get; set; }
        public int CategoryId { get; set; }
        public int UserId { get; set; }
    }
}
