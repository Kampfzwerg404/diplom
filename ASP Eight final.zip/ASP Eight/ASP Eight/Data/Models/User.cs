﻿namespace ASP_Eight.Data.Models
{
    public class User
    {
		public User(string name, string email, string password, int roleId)
		{
			Name = name;
			Email = email;
			Password = password;
			RoleId = roleId;
		}

		public User(int id, string name, string email, string password, int roleId)
		{
			Id = id;
			Name = name;
			Email = email;
			Password = password;
			RoleId = roleId;
		}

		public int Id { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Password { get; set; }
        public int RoleId { get; set; }
		public ICollection<Car> Cars { get; set; } = [];
		public ICollection<CartItem> CartItems { get; set; } = [];
    }
}
