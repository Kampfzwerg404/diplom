﻿using ASP_Eight.Data.Models;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ASP_Eight.Data.Service
{
    public class HelperMethods(IWebHostEnvironment environment)
    {
        private readonly IWebHostEnvironment _environment = environment;


        //Сохранение пути изображения
        public async Task<string?> SaveUploadedFile(IFormFile uploadedFile)
        {
            if (uploadedFile == null) return null;
            string path = $"/img/{uploadedFile.FileName}";
            using var fileStream = new FileStream(_environment.WebRootPath + path, FileMode.Create);
            await uploadedFile.CopyToAsync(fileStream);
            return path;
        }
    }
}
