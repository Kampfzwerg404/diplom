﻿using ASP_Eight.Data.Models;

namespace ASP_Eight.Data.ViewModels
{
    public class CarCUViewModel
    {
        public Car ModifiedCar { get; set; }
        public List<Category> Categories { get; set; } = [];
    }
}
