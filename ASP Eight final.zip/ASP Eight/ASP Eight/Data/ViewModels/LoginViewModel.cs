﻿using System.ComponentModel.DataAnnotations;

namespace ASP_Eight.Data.ViewModels
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Данное поле необходимо заполнить!")]
        public string? Name { get; set; }

        [Required(ErrorMessage = "Данное поле необходимо заполнить!")]
        public string? Password { get; set; }
    }
}
