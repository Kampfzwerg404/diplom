﻿using ASP_Eight.Data.Models;

namespace ASP_Eight.Data.ViewModels
{
    public class OneCarViewModel
    {
        public Car OneCar { get; set; } = null!;
        public string CategoryName { get; set; } = String.Empty;
    }
}
