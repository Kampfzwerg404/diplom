﻿namespace ASP_Eight.Data.ViewModels
{
    public class UserViewModel
    {
        public LoginViewModel? LoginViewModel { get; set; }
        public RegistrationViewModel? RegistrationViewModel { get; set; }
    }
}
