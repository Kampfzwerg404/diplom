﻿using ASP_Eight.Data.DatabaseContext;
using ASP_Eight.Data.Models;
using System.ComponentModel.DataAnnotations;

namespace ASP_Eight.Data.ViewModels
{
    public class RegistrationViewModel
    {
        [Required(ErrorMessage = "Данное поле необходимо заполнить!")]
        public string? Name { get; set; }

        [Required(ErrorMessage = "Данное поле необходимо заполнить!")]
        public string? Email { get; set; }

        [Required(ErrorMessage = "Данное поле необходимо заполнить!")]
        public string? Password { get; set; }

        [Required(ErrorMessage = "Данное поле необходимо заполнить!")]
        [Compare("Password", ErrorMessage = "Пароли не совпадают!")]
        public string? RepeatPassword { get; set; }

		[Required(ErrorMessage = "Выберите роль пользователя!")]
		public int RoleId { get; set; }
	}
}