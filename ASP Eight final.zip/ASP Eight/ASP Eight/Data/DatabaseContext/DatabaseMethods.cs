﻿using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using System.Linq;

namespace ASP_Eight.Data.DatabaseContext
{
    public class DatabaseMethods<T>(DbContext context) where T : class
    {
        private readonly DbContext _context = context;
        private readonly DbSet<T> _dbSet = context.Set<T>();

        // Получение всех записей
        public async Task<List<T>> GetAllItems(Expression<Func<T, bool>>? filter = null, params Expression<Func<T, object>>[] includes)
        {
            IQueryable<T> query = _dbSet;
            if (filter != null) query = query.Where(filter);
            if (includes != null) foreach (var include in includes) query = query.Include(include);
            return await query.AsNoTracking().ToListAsync();
        }

        // Получение одной записи
        public async Task<T?> GetItem(object id) => await _dbSet.FindAsync(id);
        

        // Добавление новой записи
        public async Task AddItem(T entity)
        {
            await _dbSet.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        // Обновление существующей записи
        public async Task UpdateItem(T entity)
        {
            _dbSet.Update(entity);
            await _context.SaveChangesAsync();
        }

        // Удаление текущей записи записи
        public async Task DeleteItem(int id)
        {
            if (await GetItem(id) is T entity)
            {
                _dbSet.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }

        //Удаление списка элементов
        public async Task DeleteAllItems(List<T> query)
        {
            _dbSet.RemoveRange(query);
            await _context.SaveChangesAsync();
        }
    }
}

