﻿using ASP_Eight.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace ASP_Eight.Data.DatabaseContext
{
    public class StoreContext : DbContext
    {
        public StoreContext(DbContextOptions<StoreContext> options) : base(options) => Database.EnsureCreated();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Role>().HasData(
               new Role(1, "Клиент"),
               new Role(2, "Работник")
               );
           
        }

        public DbSet<Car> Cars { get; set; } = null!;
        public DbSet<Category> Categories { get; set; } = null!;
        public DbSet<User> Users { get; set; } = null!;
        public DbSet<Role> Roles { get; set; } = null!;
        public DbSet<CartItem> CartItems { get; set; } = null!;
    }
}
