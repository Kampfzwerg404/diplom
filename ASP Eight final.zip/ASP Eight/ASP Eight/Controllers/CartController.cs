﻿using ASP_Eight.Data.DatabaseContext;
using ASP_Eight.Data.Models;
using ASP_Eight.Data.Service;
using Microsoft.AspNetCore.Mvc;

namespace ASP_Eight.Controllers
{
    public class CartController(StoreContext context, HelperMethods helperMethods) : BaseController(context, helperMethods)
    {
        private readonly DatabaseMethods<CartItem> _cartMethods = new(context);
        private readonly DatabaseMethods<Car> _carMethods = new(context);


        public async Task<IActionResult> CartList() => View(await _cartMethods.GetAllItems(ci => ci.UserId == GetUserId(), ci => ci.Car));


        //Добавление товара в корзину
        [HttpGet]
        public async Task<IActionResult> AddToCart(int carId, string returnUrl, string returnController)
        {
            var car = await _carMethods.GetItem(carId);
            if (car == null) return NotFoundResponse("Car not found.");

            var cartItem = (await _cartMethods.GetAllItems(ci => ci.UserId == GetUserId() && ci.Car.Id == carId)).FirstOrDefault();
            if (cartItem != null)
            {
                cartItem.Quantity++;
                await _cartMethods.UpdateItem(cartItem);
            }
            else await _cartMethods.AddItem(new CartItem(car, 1, GetUserId()));
            return RedirectToAction(returnUrl, returnController);
        }


        // Удаление товара из корзины
        public async Task<IActionResult> DeleteFromCart(int cartId)
        {
            var cartItem = await _cartMethods.GetItem(cartId);
            if (cartItem != null)
            {
                if (cartItem.Quantity > 1)
                {
                    cartItem.Quantity--;
                    await _cartMethods.UpdateItem(cartItem);
                }
                else await _cartMethods.DeleteItem(cartItem.Id);
            }
            return RedirectToAction("CartList");
        }


        public async Task<IActionResult> ClearCart()
        {
            var cartItems = await _cartMethods.GetAllItems(ci => ci.UserId == GetUserId());
            if (cartItems != null) await _cartMethods.DeleteAllItems(cartItems);
            return RedirectToAction("CartList");
        }


        public async Task<IActionResult> Complete()
        {
            await _cartMethods.DeleteAllItems(await _cartMethods.GetAllItems(ci => ci.UserId == GetUserId()));
            return View();
        }
        
    }
}
