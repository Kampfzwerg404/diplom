using ASP_Eight.Data.DatabaseContext;
using ASP_Eight.Data.Models;
using ASP_Eight.Data.Service;
using ASP_Eight.Data.ViewModels;
using ASP_Eight.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace ASP_Eight.Controllers
{
    [Authorize]
    public class HomeController(StoreContext context, HelperMethods helperMethods) : BaseController(context, helperMethods)
    {
        private readonly DatabaseMethods<Car> _carMethods = new(context);
        private readonly DatabaseMethods<Category> _categoryMethods = new(context);

        public async Task<IActionResult> Index(int categoryId = 0, int currentPage = 1)
        {
            int pageSize = 6;
            return View(new HomeViewModel
            {
                TotalItems = (await _carMethods.GetAllItems(car => categoryId != 0 ? car.CategoryId == categoryId && car.IsFavourite : car.IsFavourite)).Count,
                ItemsPerPage = pageSize,
                CurrentPage = currentPage,
                Cars = (await _carMethods.GetAllItems(car => categoryId != 0 ? car.CategoryId == categoryId && car.IsFavourite : car.IsFavourite)).OrderBy(car => car.CategoryId).Skip((currentPage - 1) * pageSize).Take(pageSize),
                Categories = await _categoryMethods.GetAllItems(),
                CurrentCategory = categoryId
            });
        }


        public IActionResult Privacy() => View();

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error() => View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        
    }
}
