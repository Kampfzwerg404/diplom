﻿using ASP_Eight.Data.DatabaseContext;
using ASP_Eight.Data.Models;
using Microsoft.AspNetCore.Mvc;

namespace ASP_Eight.Controllers
{
    public class CategoryController(StoreContext context) : Controller
    {
        private readonly DatabaseMethods<Category> _categoryMethods = new(context);


        public async Task<IActionResult> CategoryList() => View(await _categoryMethods.GetAllItems());


        [HttpGet]
        public IActionResult AddCategory() => View(new Category());


        [HttpPost]
        public async Task<IActionResult> AddCategory(Category category)
        {
            await _categoryMethods.AddItem(category);
            return RedirectToAction("CategoryList");
        }


        [HttpGet]
        public async Task<IActionResult> EditCategory(int categoryId) => categoryId == 0 ? RedirectToAction("CategoryList") : View(await _categoryMethods.GetItem(categoryId));
        

        [HttpPost]
        public async Task<IActionResult> EditCategory(Category category)
        {
            await _categoryMethods.UpdateItem(category);
            return RedirectToAction("CategoryList");
        }


        public async Task<IActionResult> DeleteCategory(int categoryId)
        {
            await _categoryMethods.DeleteItem(categoryId);
            return RedirectToAction("CategoryList");
        }
    }
}
