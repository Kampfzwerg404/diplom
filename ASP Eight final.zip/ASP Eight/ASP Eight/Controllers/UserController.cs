﻿using ASP_Eight.Data.DatabaseContext;
using ASP_Eight.Data.Models;
using ASP_Eight.Data.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace ASP_Eight.Controllers
{
    public class UserController(StoreContext context) : Controller
    {
        private readonly DatabaseMethods<User> _userMethods = new(context);
        private readonly DatabaseMethods<Role> _roleMethods = new(context);

        public async Task<IActionResult> Index()
		{
			await LoadRolesAsync();
			return View(new UserViewModel());
		}

		private async Task LoadRolesAsync()
		{
			ViewBag.Roles = new SelectList(await _roleMethods.GetAllItems(role => role.Id != 3), "Id", "Name");
		}

        [HttpPost]
		public async Task<IActionResult> LoginAsync([Bind(Prefix = "l")] LoginViewModel model)
        {
			await LoadRolesAsync();

			if (!ModelState.IsValid)
            {
                return View("Index", new UserViewModel { LoginViewModel = model });
            }

            var user = await _userMethods.GetAllItems(u => u.Name == model.Name && u.Password == model.Password).ContinueWith(t => t.Result.FirstOrDefault());

            if (user is null)
            {
                ViewBag.Error = "Неверные имя пользователя или пароль.";
                return View("Index", new UserViewModel { LoginViewModel = model });
            }

            await AuthenticateAsync(user);
            return RedirectToAction("Index", "Home");
        }


        [HttpPost]
        public async Task<IActionResult> RegistrationAsync([Bind(Prefix = "r")] RegistrationViewModel model)
        {
			await LoadRolesAsync();

			if (!ModelState.IsValid)
            {
                return View("Index", new UserViewModel { RegistrationViewModel = model });
            }

            if (await _userMethods.GetAllItems(u => u.Name == model.Name).ContinueWith(t => t.Result.Any()))
            {
                ViewBag.RegisterError = "Пользователь с таким именем уже существует.";
                return View("Index", new UserViewModel { RegistrationViewModel = model });
            }

            var newUser = new User(model.Name ?? string.Empty, model.Email ?? string.Empty, model.Password ?? string.Empty, model.RoleId);
            await _userMethods.AddItem(newUser);
            await AuthenticateAsync(newUser);
            return RedirectToAction("Index", "Home");
        }


        private async Task AuthenticateAsync(User user)
        {
            var claims = new List<Claim>
            {
                new(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new(ClaimsIdentity.DefaultNameClaimType, user.Name  ?? string.Empty),
                new(ClaimsIdentity.DefaultRoleClaimType, (await _roleMethods.GetItem(user.RoleId))?.Name ?? string.Empty)
            };
            var id = new ClaimsIdentity(claims, "ApplicationCookie", ClaimsIdentity.DefaultNameClaimType, ClaimsIdentity.DefaultRoleClaimType);
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(id));
        }


        public async Task<IActionResult> LogoutAsync()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index", "User");
        }
    }
}
