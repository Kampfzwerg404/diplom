﻿using ASP_Eight.Data.DatabaseContext;
using ASP_Eight.Data.Models;
using ASP_Eight.Data.Service;
using ASP_Eight.Data.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ASP_Eight.Controllers
{
    public class CarController(StoreContext context, HelperMethods helperMethods) : BaseController(context, helperMethods)
    {
        private readonly DatabaseMethods<Car> _carMethods = new(context);
        private readonly DatabaseMethods<Category> _categoryMethods = new(context);


        //Получение одной машины
        public async Task<IActionResult> GetOneCar(int carId) => (await _carMethods.GetItem(carId)) is Car car ? 
            View(new OneCarViewModel { OneCar = car, CategoryName = (await _categoryMethods.GetItem(car.CategoryId))?.Name ?? string.Empty })
            : NotFound();


        // Список всех машин
        public async Task<IActionResult> CarList() => View(await _carMethods.GetAllItems());


        // Личный список машин
        public async Task<IActionResult> PersonalCarList() => GetUserId() is int userIdClaim ? 
            View(await _carMethods.GetAllItems(car => car.UserId == userIdClaim))
            : Unauthorized();


        // Добавление машины (GET)
        [HttpGet]
        public async Task<IActionResult> AddCar() => View(new CarCUViewModel { ModifiedCar = new Car(), Categories = await _categoryMethods.GetAllItems()});


        // Добавление машины (POST)
        [HttpPost]
        public async Task<IActionResult> AddCar(CarCUViewModel model, IFormFile uploadedFile)
        {
            var userId = GetUserId();
            if (userId == 0) return Unauthorized();
            model.ModifiedCar.Img = await SaveUploadedFile(uploadedFile) ?? model.ModifiedCar.Img;
            model.ModifiedCar.UserId = userId;
            await _carMethods.AddItem(model.ModifiedCar);
            return RedirectToAction("CarList");
        }


        // Редактирование машины (GET)
        [HttpGet]
        public async Task<IActionResult> EditCar(int carId) => (await _carMethods.GetItem(carId)) is Car car ?
            View("AddCar", new CarCUViewModel { ModifiedCar = car, Categories = await _categoryMethods.GetAllItems() }) : NotFound();


        // Редактирование машины (POST)
        [HttpPost]
        public async Task<IActionResult> EditCar(CarCUViewModel model, IFormFile uploadedFile)
        {
            var userId = GetUserId();
            if (userId == 0) return Unauthorized();
            model.ModifiedCar.Img = await SaveUploadedFile(uploadedFile) ?? model.ModifiedCar.Img;
            model.ModifiedCar.UserId = userId;
            await _carMethods.UpdateItem(model.ModifiedCar);
            return RedirectToAction("PersonalCarList");
        }


        // Удаление машины
        public async Task<IActionResult> DeleteCar(int carId)
        {
            await _carMethods.DeleteItem(carId);
            return RedirectToAction("PersonalCarList");
        }
    }
}