﻿using ASP_Eight.Data.DatabaseContext;
using ASP_Eight.Data.Service;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ASP_Eight.Controllers
{
    public abstract class BaseController(StoreContext context, HelperMethods helperMethods) : Controller
    {
        protected readonly StoreContext _context = context;
        protected readonly HelperMethods _helperMethods = helperMethods;

        // Получает ID текущего пользователя.
        protected int GetUserId() => int.TryParse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value, out var userId) ? userId : 0;


        // Сохранение загружаемого файла и возврат пути.
        protected async Task<string?> SaveUploadedFile(IFormFile file) => await _helperMethods.SaveUploadedFile(file);


        // Обработка ошибок с универсальным сообщением.
        protected IActionResult HandleError(string message, Exception? exception = null) => BadRequest(new { error = message, details = exception?.Message });
        

        // Унифицированный метод возврата NotFound.
        protected IActionResult NotFoundResponse(string message)
        {
            return NotFound(new { error = message });
        }
    }
}
